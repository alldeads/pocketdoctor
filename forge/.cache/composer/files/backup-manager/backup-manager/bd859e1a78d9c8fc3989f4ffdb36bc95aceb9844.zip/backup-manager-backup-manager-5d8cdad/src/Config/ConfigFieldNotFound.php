<?php namespace BackupManager\Config;

/**
 * Class ConfigFieldNotFound
 * @package BackupManager\Config
 */
class ConfigFieldNotFound extends \Exception {}
