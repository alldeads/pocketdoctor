<?php namespace BackupManager\Filesystems;

/**
 * Class FilesystemTypeNotSupported
 * @package BackupManager\Filesystems
 */
class FilesystemTypeNotSupported extends \Exception {}
