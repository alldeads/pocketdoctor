<?php namespace BackupManager\ShellProcessing;

/**
 * Class ShellProcessFailed
 * @package BackupManager\ShellProcessing
 */
class ShellProcessFailed extends \Exception {}
