<?php

namespace Sentry\Laravel;

final class Version
{
    public const SDK_IDENTIFIER = 'sentry.php.laravel';
    public const SDK_VERSION = '1.7.1';
}
