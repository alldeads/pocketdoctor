<?php

namespace ClassesWithParents;

class G
{
    use CTrait;
}
