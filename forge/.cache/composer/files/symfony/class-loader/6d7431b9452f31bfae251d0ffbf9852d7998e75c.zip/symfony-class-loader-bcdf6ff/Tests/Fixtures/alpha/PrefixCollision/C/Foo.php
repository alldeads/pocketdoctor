<?php

class PrefixCollision_C_Foo
{
    public static $loaded = true;
}
