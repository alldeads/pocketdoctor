<?php

namespace NamespaceCollision\C\B;

class Bar
{
    public static $loaded = true;
}
